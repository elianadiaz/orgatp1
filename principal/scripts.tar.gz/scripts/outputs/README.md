# orgatp0 
TP 1 Organizacion de computadores 66.20 
 
Carpeta donde se van a guardar los archivos output resultado de los tests automaticos. 
